# Interactive Color

A Pen created on CodePen.

Original URL: [https://codepen.io/Hendrik-Hsu-the-scripter/pen/gbgxJvw](https://codepen.io/Hendrik-Hsu-the-scripter/pen/gbgxJvw).

